# Power_BI_Global_SalesInsights
This project is based on global sales insights which is visualize through PowerBI tool.

![sales_insight](https://user-images.githubusercontent.com/113979076/228132883-c3a73117-3500-488f-b687-2221956e152f.png)
