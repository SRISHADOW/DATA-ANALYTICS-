# Retail_Shopping_EDA

In this repository I will be analyzing a customer shopping datset that I found on Kaggle. 
First I did a EDA on a jupyter notebook with python and then a sales report on Power BI.

I am new to the data analysis world. I´ll be more that happy to hear your feedback and advice. 
