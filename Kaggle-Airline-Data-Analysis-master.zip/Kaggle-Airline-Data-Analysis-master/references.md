# References
 1. $2.7 trillion in world economic activity : <a href="https://aviationbenefits.org/economic-growth/adding-value-to-the-economy/" target="_blannk">https://aviationbenefits.org/economic-growth/adding-value-to-the-economy/</a>
 2. 22.4 per cent of world traffic was from  : <a href="https://www.icao.int/annual-report-2018/Pages/the-world-of-air-transport-in-2018.aspx" target="_blannk">https://www.icao.int/annual-report-2018/Pages/the-world-of-air-transport-in-2018.aspx</a>


<div class="parent" style="display: inline-block;width: 100%;">
    <div class="header3" style="display: inline;float: left;width: 50%;">
        <a href="glossary"><img src="images/prev-page.png" style="max-width: 50px"></a>
    </div>
</div>