---
layout: default
---
<div class="parent" style="display: inline-block;width: 100%;">
    <div class="header3" style="display: inline;float: left;width: 80%;">
        <h1 id="kaggle-airline-delay--cancellation-analysis">{{site.title}}</h1>
    </div>
    <div style="text-align: right;display: inline;cursor:pointer;float: right;right: -6px;" align="right"> 
        <a href="motivation"><img src="images/next-page.png" style="max-width: 50px"></a>
    </div>
</div>

{{site.description_detail}}

![](images/airport.jpg)
<center>Image by <a target="_blank" href="https://pixabay.com/users/JESHOOTS-com-264599/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2373727">Jan Vašek</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2373727">Pixabay</a></center>
