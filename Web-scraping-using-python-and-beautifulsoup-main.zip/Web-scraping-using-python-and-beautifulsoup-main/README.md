# Web-scraping-using-python-and-beautifulsoup

This notebook includes data scraping, for this beautifulsoup and selinium is used. It which takes a website URL as an input and extracts the information listed below as an output from that webpage.
1. Specific HTML tags along with titles and meta description
2. Extract specific tags, heading tags from h1-h6 along with titles and meta description
3. Extracting ALT tags
4. Counting words inside a web page
5. Inspection of broken links inside a webpage
6. Extracting the source code of the webpage in google colab
7. Extracting all URLs from a website without duplication
8. Measuring the forntend and backend performance of website
