# HR Analytics Dashboard Power BI

<b><h2>Objective :- </h2></b>
Help an organization to improve employee performance and improve employee retention (Reduce Attrition) by creating a HR Analytics Dashboard.</br>

![Alt text](HR%20Analytics%20Dashboard%20Image.png)</br>
 
<b><h2>Project Description :- </h2></b> 

<ul>
<li>Identified key fectors to reduce attrition.
<li>Improved the hiring process.
<li>Improved employee experience.
<li>Made workforce more productive.
<li>Gained employee trust.
</ul>

<b><h2>Contact :- </h2></b>
Linkedln : https://www.linkedin.com/in/vikas-vachheta/ <br> 
Email : vikasvachheta.ds@gmail.com