# Learn SQL Basics For Data Science Specialization

![UC DAVIS, University of CALIFORNIA](https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/xdp/ucdavis.svg?auto=format%2Ccompress&dpr=1&h=70)

# Main 4 Courses of this Specialization 
|Course|Done✅|Not YET⏳|Link 🔗|
|-|-|-|-|
|__Course 1: SQL for Data Science__ |✅|-|[🌐 Course1](https://github.com/ayoub-berdeddouch/Learn_SQL_Basics_4_DataScience_Spec/tree/main/SQL_4_DataScience)|
|__Course 2: Data Wrangling, Analysis and AB Testing with SQL__|-|⏳|[🌐]()|
|__Course 3: Distributed Computing with Spark SQL__|-|⏳|[🌐]()|
|__Course 4: SQL for Data Science Capstone Project__|-|⏳|[🌐]()|





