# Course 1: SQL for Data Science

## Getting Started and Selecting & Retrieving data with SQL
### Module 1: SQL CODE

## Filtering, Sorting, and Calculating Data with SQL
### Module 2: SQL CODE

## Subqueries and Joins in SQL
### Module 3: SQL CODE

## Modifying and Analyzing Data with SQL 
### Module 4: SQL CODE
### PEER REVIEW ASSIGNEMENT: 
  * Data Scientist Role Play : Profiling & Analyzing YELP DATASET
